
    // Define vars for scope
    let userDisplayName, mydata, cookieIncrement, visitnumber;

    // Show social login options
    jQuery('.button4').click(function(e) {
        jQuery('.socialWrapper').addClass('.socialWrapper visible');
    });

    // Display User Info
    if (typeof mydata !== 'undefined') {
        JSON.parse(mydata);
        console.log(mydata);
        jQuery('.username').text(userDisplayName = mydata.user.firstName);
    } else {
        jQuery('.username').text(userDisplayName = 'Guest');
    }

    // Social Login
    (function socialLogin(){
        let params = {
            headerText: '&nbsp;',
            containerID: 'socialLogin',
            showTermsLink: false,
            //redirectURL: '//localhost/a.html',
            width: '200px'
        };
        params['onLoad'] = function (evt) {
            evt['msg'] = 'After onLoad';
            let msg = 'Event name is : ' + evt.eventName + '\n';
            msg += 'evt[\'msg\'] is : ' + evt['msg'] + '\n';
            msg += 'context.msg is : ' + evt['context']['msg'];
        };
        gigya.socialize.showLoginUI(params);
    })();

    // Social Logout
    function logoutFromGS() {
        gigya.socialize.logout(); // logout from Gigya platform
    }


    // Initiate Socialize
    gigya.socialize.addEventHandlers({
            onLogin: FireLoginEvents,
            onLogout: FireLogoutEvents
        }
    );

    // Callback - Login
    function FireLoginEvents(eventObj) {
        // Store callback data as a cookie - set logged in cookie to True
        Cookies.set('userData', JSON.stringify(eventObj), 7);
        Cookies.set('LoggedIn', 'True', 7);

        // Increment Visitor Number
        cookieIncrement = Cookies.get(eventObj.UID);
        if (typeof cookieIncrement !== 'undefined'){
            cookieIncrement = parseInt(cookieIncrement) + 1;
            Cookies.set(eventObj.UID, cookieIncrement);
        } else {
            Cookies.set(eventObj.UID, 1);
        }

        // Add / Verify Email
        jQuery('#validEmail').val(eventObj.user.email);

        // Show Email Form
        jQuery('#sign_up').lightbox_me({
            centered: true
        })
    }

    // Callback - Logout
    function FireLogoutEvents(eventObj){
        Cookies.remove('LoggedIn');
    }

    gigya.socialize.getUserInfo({callback:RetrieveUserData});

    function RetrieveUserData(response){
        if (typeof response.UID !== 'undefined'){
            document.getElementById('visitorCount').textContent=Cookies.get(response.UID);

            // Display User Info
            jQuery('.username').text(userDisplayName = response.user.firstName);
            jQuery('.welcomeUsername, .visitorCounter').removeClass('hidden');
        } else {
            jQuery('.username').text(userDisplayName = 'Guest');
            jQuery('.welcomeUsername').removeClass('hidden');
        }
    }
