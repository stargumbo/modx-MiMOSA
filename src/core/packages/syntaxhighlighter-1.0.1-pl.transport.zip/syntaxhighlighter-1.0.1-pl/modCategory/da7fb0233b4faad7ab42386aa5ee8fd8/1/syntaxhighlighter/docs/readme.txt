--------------------
Plugins: SyntaxHighlighter
--------------------
Author: Alex Gorbatchev
Author: Bob Ray <http://bobsguides.com>
Theme property and updates thanks to AlexZem

Official Documentation: http://bobsguides.com/syntaxhighlighter-tutorial.html
Bugs and Feature Requests: https://github.com/BobRay/syntaxhighlighter
Questions: http://modxcms.com/forums

SyntaxHighlighter is fairly straight port of Alex Gorbatchev's great JS syntax highlighter, adapted for MODX Revolution. The package includes both a plugin and a snippet version of the highlighter. All of the code in this component, other than the plugin, snippet, and install script, was written by Alex Gorbatchev.
