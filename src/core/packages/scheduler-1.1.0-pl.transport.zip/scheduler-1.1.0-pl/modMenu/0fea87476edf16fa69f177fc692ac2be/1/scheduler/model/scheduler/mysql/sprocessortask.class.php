<?php
require_once (dirname(dirname(__FILE__)) . '/sprocessortask.class.php');
class sProcessorTask_mysql extends sProcessorTask {}