<?php
$xpdo_meta_map['sSnippetTask']= array (
  'package' => 'scheduler',
  'version' => '1.1',
  'extends' => 'sTask',
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
