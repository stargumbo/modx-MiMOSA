<?php
$xpdo_meta_map['sProcessorTask']= array (
  'package' => 'scheduler',
  'version' => '1.1',
  'extends' => 'sTask',
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
