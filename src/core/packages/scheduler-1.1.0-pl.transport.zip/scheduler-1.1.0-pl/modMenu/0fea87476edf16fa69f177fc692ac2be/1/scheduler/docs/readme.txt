--------------------------------------------
Scheduler - Handles scheduling tasks in the future
--------------------------------------------
Author: Mark Hamstra - support@modmore.com
        Bert Oost - support@modmore.com
--------------------------------------------

Scheduler is a package for MODX Revolution that handles scheduling tasks in
the future. It is meant to provide an easy to integrate and administer
scheduling engine for developers. At modmore it is used in our billing and
registration systems and probably much, much more in the future.