<?php
require_once (dirname(dirname(__FILE__)) . '/sfiletask.class.php');
class sFileTask_mysql extends sFileTask {}