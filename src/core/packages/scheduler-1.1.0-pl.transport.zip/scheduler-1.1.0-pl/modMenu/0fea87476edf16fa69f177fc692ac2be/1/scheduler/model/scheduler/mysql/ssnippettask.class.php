<?php
require_once (dirname(dirname(__FILE__)) . '/ssnippettask.class.php');
class sSnippetTask_mysql extends sSnippetTask {}